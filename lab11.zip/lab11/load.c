#include <stdio.h>
#include <string.h>
#include <sqlite3.h>

int main(int argc, char** argv) {
	//Error checking the command line
	if(argc != 4) {
    	fprintf(stderr, "USAGE: %s <database file> <table name> <CSV file>\n", argv[0]);
    	return 1;
    }

    //Variables
	sqlite3 *db;
	sqlite3_stmt *stmt;

	//Open the database file
	int open = sqlite3_open(argv[1], &db);

	if(open != SQLITE_OK) {
		printf("ERROR opening SQLite DB in memory: %s\n", sqlite3_errmsg(db));
		sqlite3_close(db);
		return 1;
	}

	//Prepare the statement
	sqlite3_prepare_v2(db, "DELETE FROM mytable;", -1, &stmt, NULL);

	//Step through the database
	sqlite3_step(stmt);

	//Open CSV file
	FILE *file = fopen(argv[3], "r");
	
	//Variables for the query
	char line[50];
	char insertSQL[100];

	//Do everything as long as the file is not empty
	while(fgets(line, 50, file) != NULL) {
		if(feof(file)) {
			break;
		}

		sprintf(insertSQL, "INSERT INTO mytable VALUES(%s);", line);
		sqlite3_prepare_v2(db, insertSQL, -1, &stmt, NULL);
		sqlite3_step(stmt);
	}

	//Closing file
	fclose(file);
	sqlite3_finalize(stmt);

	//Closing database
	sqlite3_close(db);

  	return 0;
}