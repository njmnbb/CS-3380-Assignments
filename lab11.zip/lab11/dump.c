#include <stdio.h>
#include <sqlite3.h>

int main(int argc, char** argv) {
	//Error checking the command line
  	if(argc != 4) {
      	fprintf(stderr, "USAGE: %s <database file> <table name> <CSV file>\n", argv[0]);
      	return 1;
    }

    //Variables
	sqlite3 *db;
	sqlite3_stmt *stmt;

	//Open the database file
	int open = sqlite3_open(argv[1], &db);

	if(open != SQLITE_OK) {
        printf("ERROR opening SQLite DB in memory: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }

	//Prepare the statement
	sqlite3_prepare_v2(db, "SELECT * FROM mytable", -1, &stmt, NULL);
	
	//Step through the database
	FILE *file = fopen(argv[3], "w");
	while(sqlite3_step(stmt) == SQLITE_ROW) {
		int i = 0;
		for(i = 0; i < sqlite3_column_count(stmt); i++) {

			//If the column is an integer...
			if(sqlite3_column_type(stmt, i) == SQLITE_INTEGER) {
				fprintf(file, "%d", sqlite3_column_int(stmt, i));
			}

			//If the column is text...
			else if(sqlite3_column_type(stmt, i) == SQLITE_TEXT) {
				fprintf(file, "'%s'", sqlite3_column_text(stmt, i));
			}

			//If this is not the last column...
			if(i != sqlite3_column_count(stmt) - 1) {
				fprintf(file, ",");
			}
		}
		//Add new line after each row
		fprintf(file, "\n");
	}

	//Closing file
	fclose(file);
	sqlite3_finalize(stmt);

	//Closing database
	sqlite3_close(db);

  	return 0;
}
